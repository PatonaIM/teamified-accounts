import { Card, CardContent } from "@/components/ui/card"
import { User, Clock, Calendar, Upload, FileText, HelpCircle } from "lucide-react"

const dashboardActions = [
  {
    id: 1,
    title: "Complete Profile",
    description: "Update your personal information and employment details",
    icon: User,
    type: "platform" as const,
    href: "/profile",
  },
  {
    id: 2,
    title: "Submit Timesheet",
    description: "Log your working hours for accurate payroll processing",
    icon: Clock,
    type: "platform" as const,
    href: "/timesheet",
  },
  {
    id: 3,
    title: "Request Leave",
    description: "Submit vacation, sick leave, or other time-off requests",
    icon: Calendar,
    type: "platform" as const,
    href: "/leave",
  },
  {
    id: 4,
    title: "Upload CV",
    description: "Keep your resume current for internal opportunities",
    icon: Upload,
    type: "service" as const,
    href: "/cv",
  },
  {
    id: 5,
    title: "View Documents",
    description: "Access contracts, policies, and important documents",
    icon: FileText,
    type: "service" as const,
    href: "/documents",
  },
  {
    id: 6,
    title: "Get Help",
    description: "Contact support or browse our knowledge base",
    icon: HelpCircle,
    type: "platform" as const,
    href: "/help",
  },
]

export default function Dashboard() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--eor-section-bg)" }}>
      {/* Header Section */}
      <div className="py-16" style={{ backgroundColor: "var(--eor-background)" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center">
            <h1 className="text-h1 text-balance mb-4" style={{ color: "var(--eor-text-primary)" }}>
              Welcome to Your Team Member Portal
            </h1>
            <p className="text-body-large text-pretty max-w-2xl mx-auto" style={{ color: "var(--eor-text-secondary)" }}>
              Manage your employment journey with our comprehensive EOR platform. Access all the tools you need to stay
              connected and productive.
            </p>
          </div>
        </div>
      </div>

      {/* Dashboard Actions */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-12">
            <h2 className="text-h2 text-center mb-4" style={{ color: "var(--eor-text-primary)" }}>
              Quick Actions
            </h2>
            <p className="text-body-medium text-center" style={{ color: "var(--eor-text-secondary)" }}>
              Everything you need to manage your employment in one place
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {dashboardActions.map((action) => {
              const IconComponent = action.icon
              const iconColor = action.type === "platform" ? "var(--eor-primary)" : "var(--eor-secondary)"

              return (
                <Card
                  key={action.id}
                  className="group cursor-pointer transition-all duration-200 hover:shadow-lg border-0 rounded-lg"
                  style={{
                    backgroundColor: "var(--eor-background)",
                    borderColor: "var(--eor-border)",
                    border: "1px solid var(--eor-border)",
                  }}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div
                        className="flex-shrink-0 p-3 rounded-lg transition-colors duration-200 group-hover:bg-opacity-20"
                        style={{
                          backgroundColor: `${iconColor}15`,
                        }}
                      >
                        <IconComponent size={24} strokeWidth={2} style={{ color: iconColor }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3
                          className="text-h3 mb-2 group-hover:opacity-80 transition-opacity"
                          style={{ color: "var(--eor-text-primary)" }}
                        >
                          {action.title}
                        </h3>
                        <p className="text-body-medium text-pretty" style={{ color: "var(--eor-text-secondary)" }}>
                          {action.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </div>

      {/* Footer Section */}
      <div className="py-12" style={{ backgroundColor: "var(--eor-background)" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center">
            <p className="text-body-medium" style={{ color: "var(--eor-text-tertiary)" }}>
              Need assistance? Contact our support team at{" "}
              <span style={{ color: "var(--eor-primary)" }}>support@company.com</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
