import { InvitationsPage } from "@/components/invitations-page"

export default function Home() {
  return <InvitationsPage />
}
