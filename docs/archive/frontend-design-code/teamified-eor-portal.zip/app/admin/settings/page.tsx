export default function SettingsPage() {
  return (
    <div>
      <h1 className="h2 mb-4">Settings</h1>
      <div className="card">
        <div className="card-body">
          <p className="body-md">Settings page coming soon...</p>
        </div>
      </div>
    </div>
  )
}
