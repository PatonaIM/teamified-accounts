export default function AdminDocumentsPage() {
  return (
    <div>
      <h1 className="h2 mb-4">Documents</h1>
      <div className="card">
        <div className="card-body">
          <p className="body-md">Document publishing page coming soon...</p>
        </div>
      </div>
    </div>
  )
}
