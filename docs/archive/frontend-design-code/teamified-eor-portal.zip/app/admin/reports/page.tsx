export default function ReportsPage() {
  return (
    <div>
      <h1 className="h2 mb-4">Reports</h1>
      <div className="card">
        <div className="card-body">
          <p className="body-md">Reports page coming soon...</p>
        </div>
      </div>
    </div>
  )
}
