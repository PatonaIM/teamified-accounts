"use client"

import { ThemeProvider, createTheme } from "@mui/material/styles"
import { CssBaseline } from "@mui/material"
import { EmploymentRecords } from "@/components/employment-records"

const muiTheme = createTheme({
  palette: {
    primary: {
      main: "#A16AE8",
    },
    secondary: {
      main: "#8096FD",
    },
    success: {
      main: "#10B981",
    },
    warning: {
      main: "#F59E0B",
    },
    error: {
      main: "#EF4444",
    },
    info: {
      main: "#3B82F6",
    },
    text: {
      primary: "#1F2937",
      secondary: "#6B7280",
    },
    background: {
      default: "#F9FAFB",
      paper: "#FFFFFF",
    },
  },
  typography: {
    fontFamily: "var(--font-geist-sans), system-ui, sans-serif",
    h3: {
      fontSize: "36px",
      fontWeight: 700,
    },
    h4: {
      fontSize: "30px",
      fontWeight: 700,
    },
    h6: {
      fontSize: "20px",
      fontWeight: 600,
    },
    caption: {
      fontSize: "12px",
    },
  },
  shape: {
    borderRadius: 12,
  },
})

export default function Page() {
  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <EmploymentRecords />
    </ThemeProvider>
  )
}
