"use client"

import type React from "react"

import { Box, Paper, Typography, Button } from "@mui/material"
import { Users, UserCheck, UserX, UserPlus } from "lucide-react"

interface StatCardProps {
  title: string
  value: string
  icon: React.ElementType
  color: string
  bgColor: string
}

function StatCard({ title, value, icon: Icon, color, bgColor }: StatCardProps) {
  return (
    <Paper
      elevation={0}
      sx={{
        flex: 1,
        p: 1,
        borderRadius: 2,
        border: "1px solid #E5E7EB",
        display: "flex",
        alignItems: "center",
        gap: 1,
        transition: "all 0.2s ease",
        "&:hover": {
          transform: "translateY(-2px)",
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
        },
      }}
    >
      <Box
        sx={{
          width: 32,
          height: 32,
          borderRadius: 2,
          backgroundColor: bgColor,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <Icon size={16} color={color} />
      </Box>
      <Box sx={{ minWidth: 0 }}>
        <Typography
          variant="caption"
          sx={{
            textTransform: "uppercase",
            fontWeight: 600,
            letterSpacing: "0.5px",
            color: "text.secondary",
            display: "block",
            mb: 0.25,
            fontSize: "0.65rem",
          }}
        >
          {title}
        </Typography>
        <Typography
          variant="h5"
          sx={{
            fontWeight: 700,
            color: "text.primary",
            lineHeight: 1,
          }}
        >
          {value}
        </Typography>
      </Box>
    </Paper>
  )
}

export function EmploymentRecords() {
  return (
    <Box sx={{ p: 3 }}>
      <Paper
        elevation={0}
        sx={{
          p: 3,
          mb: 4,
          borderRadius: 3,
          border: "1px solid #E5E7EB",
          background: "linear-gradient(135deg, rgba(161, 106, 232, 0.05) 0%, rgba(128, 150, 253, 0.05) 100%)",
        }}
      >
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Box>
            <Typography variant="h3" sx={{ fontWeight: 700, mb: 1 }}>
              Employment Records
            </Typography>
            <Typography variant="h6" sx={{ color: "text.secondary" }}>
              Manage employment relationships and track history
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<UserPlus size={20} />}
            sx={{
              borderRadius: 2,
              px: 3,
              py: 1.5,
              fontWeight: 600,
              textTransform: "none",
              background: "linear-gradient(135deg, #A16AE8 0%, #8096FD 100%)",
              boxShadow: "0 4px 15px rgba(161, 106, 232, 0.3)",
              "&:hover": {
                background: "linear-gradient(135deg, #8B5AE8 0%, #6B86FD 100%)",
                boxShadow: "0 6px 20px rgba(161, 106, 232, 0.4)",
              },
            }}
          >
            Add Record
          </Button>
        </Box>
      </Paper>

      <Box sx={{ display: "flex", gap: 1 }}>
        <StatCard title="Total Records" value="25" icon={Users} color="#A16AE8" bgColor="rgba(161, 106, 232, 0.1)" />
        <StatCard title="Active" value="9" icon={UserCheck} color="#10B981" bgColor="rgba(16, 185, 129, 0.1)" />
        <StatCard title="Terminated" value="0" icon={UserX} color="#EF4444" bgColor="rgba(239, 68, 68, 0.1)" />
        <StatCard title="Recent Hires" value="0" icon={UserPlus} color="#8096FD" bgColor="rgba(128, 150, 253, 0.1)" />
      </Box>
    </Box>
  )
}
